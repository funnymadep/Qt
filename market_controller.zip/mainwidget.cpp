#include "mainwidget.h"

mainwidget::mainwidget(QWidget *parent) : QMainWindow(parent)
{

}
