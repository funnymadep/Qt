#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    startTimer(1000);
    this->setFixedSize(640, 480);
    pixmap = new QPixmap(640, 480);
    pixmap->fill();

    sangle = mangle = hangle = 0;
}

Widget::~Widget()
{
}

void Widget::paintEvent(QPaintEvent *ev)
{
    QPainter p(pixmap);
    QPen pen(Qt::red, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    pen.setWidth(10);
    p.setPen(pen);
    p.translate(this->width()/2, this->height()/2);
    p.drawEllipse(QPoint(0, 0), 200, 200);
    p.drawLine(QPoint(0, 190), QPoint(0, 200));
    p.drawLine(QPoint(0, -190), QPoint(0, -200));
    p.drawLine(QPoint(190, 0), QPoint(200, 0));
    p.drawLine(QPoint(-190, 0), QPoint(-200, 0));

    QPainter hp(this);
    QPainter mp(this);
    QPainter sp(this);

    hp.drawPixmap(0, 0, *pixmap);
    hp.translate(this->width()/2, this->height()/2);

    mp.drawPixmap(0, 0, *pixmap);
    mp.translate(this->width()/2, this->height()/2);

    sp.drawPixmap(0, 0, *pixmap);
    sp.translate(this->width()/2, this->height()/2);


    QPen hpen(Qt::green, 7, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    hp.setPen(hpen);
    hp.rotate(hangle);
    hp.drawLine(QPoint(0, 0), QPoint(0, 50));

    QPen mpen(Qt::green, 5, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    mp.setPen(mpen);
    mp.rotate(mangle);
    mp.drawLine(QPoint(0, 0), QPoint(100, 0));

    QPen spen(Qt::darkGreen, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    sp.setPen(spen);
    sp.rotate(sangle);
    sp.drawLine(QPoint(0, 0), QPoint(-150, 0));
    update();
}

void Widget::timerEvent(QTimerEvent *ev)
{

    sangle += 6;
    if (360 == sangle){
        mangle += 6;
        sangle = 0;
    }
    if(360 == mangle){
        mangle = 0;
        hangle += 30;
    }
    //update();
}

